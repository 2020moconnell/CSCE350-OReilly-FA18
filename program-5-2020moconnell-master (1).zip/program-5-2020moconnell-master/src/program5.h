#ifndef PROGRAM4_H
#define PROGRAM4_H

#include <string>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

typedef struct char_freq {
	char c;
	double freq;

	char_freq() {
		this->c = '~';
		this->freq = 0.0;
	}

	char_freq(char c, double freq)
		:c(c),
		freq(freq)
	{}
} CFreq;

typedef struct char_code {
	char c;
	std::string code;
	char_code(char c, std::string code)
		:c(c),
		code(code)
	{}
} CCode;

struct huffman_node {
	char_freq data;
	huffman_node* lf;
	huffman_node* ri;

	huffman_node(char_freq data) {
		lf = ri = NULL;
		this->data = data;
	}
};

struct node_freq_greater_than {
	bool operator() (huffman_node* l, huffman_node* r) {
		return (l->data.freq > r->data.freq);
	}
};

void get_codes(struct huffman_node* root, std::string code, std::vector<CCode>& codes) {
	if (root == NULL) {
		return;
	}
	if (root->data.c != '~') {
		codes.push_back(CCode(root->data.c, code));
	}
	get_codes(root->lf, code + "0", codes);
	get_codes(root->ri, code + "1", codes);
}

std::priority_queue<huffman_node*, std::vector<huffman_node*>, node_freq_greater_than> doThing
	(std::priority_queue<huffman_node*, std::vector<huffman_node*>, 
	node_freq_greater_than> tree)
{
	huffman_node* lf;
	huffman_node* ri;
	huffman_node* tmp;
	lf = tree.top();
	tree.pop();
	ri = tree.top();
	tree.pop();

	tmp = new huffman_node(CFreq('~', lf->data.freq + ri->data.freq));
	tmp->lf = lf;
	tmp->ri = ri;
	tree.push(tmp);
	return tree;
}

std::vector<CCode> getHuffCodes(std::vector<CFreq > cfs) {
	std::priority_queue<huffman_node*, std::vector<huffman_node*>,
		node_freq_greater_than> huffman_tree;
	std::vector<CCode> codes;
	for (CFreq item : cfs) {
		huffman_tree.push(new huffman_node(item));
	}

	while (huffman_tree.size() > 1 || huffman_tree.size() < 1)
	{
		huffman_tree = doThing(huffman_tree);
	}

	get_codes(huffman_tree.top(), "", codes);
	return codes;
}

#endif //PROGRAM4_H
