//Maggie O'Connell
#ifndef PROGRAM6_H
#define PROGRAM6_H

#include <string>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using std::vector;



typedef struct coin_row_solution{
    int val;
    std::vector< int > coin_indices;

} CRS;

/*
 * Input: vector of coins in order
 * Output: a coin_row_solution, the val set to the value of the optimal solution
 *         the coin_indices (0-indexed) set to the indices of the coins forming the optimal solution
 * Must be done with Dynamic Programming -- no points for recursive solution
 */
CRS solve_coin_row(std::vector< int> coin_row)
{
	CRS soln;
	std::vector<int> F;
	F.push_back(0);
	auto it = coin_row.begin();
	coin_row.insert(it, 0);
	F.push_back(coin_row.at(1));
	for (int i = 2; i < coin_row.size(); ++i) {
		int max = std::max((coin_row.at(i) + F.at(i - 2)), F.at(i-1));
		F.push_back(max);
	}

	int i = F.size() - 1;
	int FT = 0;
	while (FT == 0) 
	{
		if (i >= F.size())
			FT = 1;
		else if (F.at(i) == F.at(i - 1))
			i--;
		int temp = F.at(i) - coin_row.at(i);
		auto iter = F.begin() + i;		
		auto temp_it = std::find(F.begin(), iter, temp);
		if (*temp_it == F.at(F.size() - 1))
			FT = 1;
		soln.coin_indices.push_back(i-1);
		i = std::distance(F.begin(), temp_it);
		if (temp == 0)
			FT = 1;
		if (FT == 1)
		break;
	}
	
	soln.val = F.at(F.size() - 1);
	return soln;

}


/*
 * Robot coin pickup dynamic programming soln
 *
 */

enum Move {Right,Down};

typedef struct robot_coin_solution{
    int n;
    std::vector<Move> moves;
}RCS;

/*
 * Input: vector<vector<bool > > coins : (inner vector is x/column direction, index like a matrix)
 * Output: an RCS (above): n is the max number of coins, moves is a vector of moves
 *    the vector of moves must take the robot from the upper left to the lower right
 *    of course, the moves must also allow the robot to pick up the maximum number of coins
 *    think of the vector of moves that if followed from index 0, 1, ... give a the plan
 *    for the robot starting at the upper left (0,0)
 */
RCS solve_robot_coin(vector<vector<bool> > coins)
{
  RCS soln;
  int n = coins.size();
  int m = coins.at(0).size();
  std::vector<vector<int>> F(n,std::vector<int>(m));
  F[0][0] = coins[0][0];
  for(int j = 1; j < m; ++j)
  {
    F[0][j] = F[0][j-1] + coins[0][j];
  }

  for(int i = 1; i < n; ++i)
  {
    F[i][0] = F[i-1][0] + coins[i][0];
    for(int j = 1; j < m; ++j)
    {
      F[i][j] = std::max(F[i-1][j],F[i][j-1]) + coins[i][j];
    }
  }
  int x = n-1;
  int y = m-1;
  int TF = 0;
  while(TF == 0)
  {
    if (x == 0 && y ==0)
      TF = 1;
    else if (x == 0) 
    {
      y--;
      soln.moves.push_back(Right);
    }
    else if (y == 0)
    {
      x--;
      soln.moves.push_back(Down);
    }
    else if (F[x-1][y] >= F[x][y-1])
    {
      soln.moves.push_back(Down);
      x--;
    }
    else if (F[x-1][y] < F[x][y-1])
    {
      soln.moves.push_back(Right);
      y--;
    }
    if (TF == 1)
      break;
  }
  
  std::reverse(soln.moves.begin(),soln.moves.end());
  soln.n = F.at(n-1).at(m-1);
  return soln;
}

#endif //PROGRAM6_H
