#ifndef ALGS_H
#define ALGS_H

#include <algorithm>
#include <queue>
using std::swap;

//note returns INDEX of median
//does NOT move the median into the pivot position
template<typename T> inline
int medianOf3(T A[], int l, int r){
	//this is overcommented... also, try and avoid using pointers
	T* a = A + l;//array name is just pointer to 1st (0 index) elem., + l shifts l*(T size)
	T* b = A + l + (r-l)/2;//middle item... int division rounds down
	T* c = A + r;

	//when a is a pointer, *a is the dereference operator (gives value a points to)
	T* m;
	if(*a < *b){
		if(*b < *c) m=b; 
		else if(*c < *a) m=a;
		else m=c;
	} else{ //b <=a
		if(*a < *c) m=a;
		else if(*c < *b) m=b;
		else m=c;
	}
	return m-A; //m-A is the number of elements from A[0]

}

//remember: l and r are INLCUSIVE (just like Lomuto)
//make sure to call medianOf3 on the subarray before partitioning
template<typename T>
int hoarePartition(T A[], int l, int r){
	return 0;
}

template<typename T>
void makeHeap(std::vector<T>& V, int  n, int i)
{
	int largest = i;
	int l = 2 * i + 1;
	int r = 2 * i + 2;

	//if l > root
	if (l < n && V[l] > V[largest])
		largest = l;

	// If r > largest
	if (r < n && V[r] > V[largest])
		largest = r;

	// If largest is not root
	if (largest != i)
	{
		swap(V[i], V[largest]);
		makeHeap(V,n, largest);
	}
}

template<typename T>
void heapsort(std::vector<T>& V)
{
	for (int i = (V.size() / 2) - 1; i >= 0; i--)
		makeHeap(V,V.size(), i);

	for (int i = V.size() - 1; i >= 0; i--)
	{
		swap(V[0], V[i]);
		makeHeap(V,i, 0);
	}
}


bool are_anagrams(std::string a, std::string b)
{
	char arr[26];
  char brr[26];
	if (a.length() != b.length())
		return false;
  else 
  {
    for (int i = 0; i < a.length(); i++)
	  {
		  arr[a.at(i)-40] += 1;
		  brr[b.at(i)-40] += 1;
	  }
  }
	
  if(arr == brr)
    return true;
	return false;
}
#endif
