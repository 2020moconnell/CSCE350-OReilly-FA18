#ifndef PROGRAM2_H
#define PROGRAM2_H

#include "metrics.h"
#include <cmath>
#include <algorithm>


//bcheck functions from cplusplus.com
struct xCheck {
	template<class T>
	bool operator() (Point<T> const &a, Point<T> const &b) const {
		return a.x < b.x;
	}
};

struct yCheck {
	template<class T>
	bool operator() (Point<T> const &a, Point<T> const &b) const {
		return a.y < b.y;
	}
};


template <typename T>
std::pair<Point<T>, Point<T> > closestPair(vector<Point<T> > v) {
	std::vector<Point<T> > xPoints = v;
	std::vector<Point<T> > yPoints = v;
	std::stable_sort(xPoints.begin(), xPoints.end(), xCheck());
	std::stable_sort(yPoints.begin(), yPoints.end(), yCheck());

	return efficientClosestPair(xPoints, yPoints);
}

template <typename T>
std::pair<Point<T>, Point<T> > efficientClosestPair(vector<Point<T> > p, vector<Point<T> > q) {
	int n = p.size();
	vector<Point<T> > pl;
	vector<Point<T> > pr;
	vector<Point<T> > ql;
	vector<Point<T> > qr;
	vector<Point<T> > s;
	decltype(p[0].x) d = 0.0;
	decltype(p[0].x) dl = 0.0;
	decltype(p[0].x) dr = 0.0;
	std::pair<Point<T>, Point<T> > close(Point<T>(0, 0), Point<T>(0, 0));

	if (n < 4) {
		return closestPairBF(p);
	}

  int w = 0;
  while(w < n)
  {
    if (w < n/2) {
			pl.push_back(p[w]);
			ql.push_back(q[w]);
		}
		else {
			pr.push_back(p[w]);
			qr.push_back(q[w]);
		}
    w++;
  }
	
	std::pair<Point<T>, Point<T> > closeLeft = efficientClosestPair(pl, ql);
	std::pair<Point<T>, Point<T> > closeRight = efficientClosestPair(pr, qr);
	dl = dist(std::get<0>(closeLeft), std::get<1>(closeLeft));
	dr = dist(std::get<0>(closeRight), std::get<1>(closeRight));
	d = std::min(dl, dr);
	decltype(p[0].x) m = p[n/2 - 1].x;

  for (auto iter = q.begin(); iter != q.end(); ++iter) {
		Point<T> temp = *iter;
		if (std::abs(temp.x - m) < d)
			s.push_back(*iter);
	}

	if (d != dr)
		close = closeLeft;
	else
		close = closeRight;


	for (auto iter = s.begin(); iter != s.end(); ++iter)
		std::cout << "S point: " << *iter << std::endl;

	n = s.size();
	int k = 0;
	decltype(p.at(0).x) squared = pow(d,2);

  w = 0;
  while(w < n-1)
  {
    k = w + 1;
		decltype(p[0].x) condition = s[k].y - s[w].y;
		condition = pow(condition,2);
		while (k <= n - 1 && condition < squared) 
    {
			Point<T> c1(s[k].x, s[k].y);
			Point<T> c2(s[w].x, s[w].y);
			decltype(p[0].x) temp_dist = dist(c1, c2);
			++k;
			if (temp_dist < d) 
      {
				std::pair <Point <T>, Point<T> > temp_pair(c1, c2);
				close = temp_pair;
				d = temp_dist;
			}
    }
    w++;
  }
	return close;
}

#endif //PROGRAM2_H

