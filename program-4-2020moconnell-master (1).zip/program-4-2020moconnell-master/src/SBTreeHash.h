#ifndef SBTREEHASH_H
#define SBTREEHASH_H

#include <map> //  a self-balancing tree (red-black)
#include <unordered_map> // a hash table
#include <string>
#include <vector>

using std::string;
using std::sort;
using std::vector;
using std::unordered_map;
using std::pair;
using std::map;

struct ana_result {
    bool found = false;
    string s1;
    string s2;
};

//Do there exist two strings that are anagrams of each other ? (use std::sort and a custom Compare)
// See https://en.cppreference.com/w/cpp/algorithm/sort
// lambda functions are fine, even preferable here
ana_result anyAnagramsSorting(vector<string> ss)
{
    ana_result res;
	std::vector<pair<string, string>> pairs;
	for (int i = 0; i < ss.size(); i++)
	{
		std::string sorted = ss.at(i);
		std::sort(sorted.begin(), sorted.end());
		pairs.push_back(std::make_pair(sorted, ss.at(i)));
	}

	std::sort(pairs.begin(), pairs.end());
	for (int i = 0; i < pairs.size() - 1; i++)
	{
		if (pairs.at(i).first == pairs.at(i + 1).first)
		{
			res.found = true;
			res.s1 = pairs.at(i).second;
			res.s2 = pairs.at(i + 1).second;
		}

	}
	return res;
}

//Do there exist two strings that are anagrams of each other ? (use map, self-balancing tree)
ana_result anyAnagramsMap(vector<string> strings)
{
	ana_result res;
	std::map<std::string, std::string> map;
	
	for (auto iter = strings.begin(); iter != strings.end(); ++iter) 
	{
		if (res.found) 
		{ 
			break; 
		}
		string sorted = *iter;
		std::sort(sorted.begin(), sorted.end());

		auto search_it = map.find(sorted);
		if (search_it != map.end()) {
			res.found = true;
			res.s1 = (*iter);
			res.s2 = (search_it->second);
		}
		map.insert(std::make_pair(sorted, *iter));
	}
    return res;
}

//Do there exist two strings that are anagrams of each other ? (use unordered_map, hash table)
ana_result anyAnagramsHash(vector<string> strings){
    ana_result res;
	std::unordered_map<std::string, std::string> table;


	for (auto iter = strings.begin(); iter != strings.end(); ++iter) {
		if (res.found) { break; }
		string sorted = *iter;
		std::sort(sorted.begin(), sorted.end());

		auto search_it = table.find(sorted);
		if (search_it != table.end()) {
			res.found = true;
			res.s1 = (*iter);
			res.s2 = (search_it->second);
		}

		table.insert(std::make_pair(sorted, *iter));
	}

    return res;
}

#endif //SBTREEHASH_H
