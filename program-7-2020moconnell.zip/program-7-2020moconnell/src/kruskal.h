//maggie O'connell
#ifndef KRUSKAL_H
#define KRUSKAL_H

#include <string>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
#include <map>
#include <set>

using std::vector;
using std::map;
using std::set;


template<typename T>
struct edge{
    T va;
    T vb;
    double wt;

    bool contains(T label){
      return va==label || vb ==label;
    }

    edge(T v1,T v2, double weight)
    : va(v1), vb(v2), wt(weight)
    {}
};

template<typename T>
bool operator==(edge<T> const& a,edge<T> const& b){
  return a.va==b.va && a.vb==b.vb && a.wt == b.wt;
}

template<typename T>
bool operator!=(edge<T> const& a,edge<T> const& b){
  return a.va!=b.va || a.vb!=b.vb || a.wt != b.wt;
}


template<typename T>
bool operator< (edge<T> const& a, edge<T> const& b){
    return a.wt < b.wt;
}

template<typename T>
bool operator> (edge<T> const& a, edge<T> const& b){
  return a.wt > b.wt;
}

template<typename T>
class graph {
public:
    void addEdge(edge<T> e){
      if(al.find(e.va) == al.end()) insertLabel(e.va);
      if(al.find(e.vb) == al.end()) insertLabel(e.vb);
      al[e.va].push_back(e);
      al[e.vb].push_back(e);
    }
    const vector<edge<T> >& getEdges(T label){
     return al[label];
    }
    typename map<T, vector< edge<T> > >::const_iterator cbegin(){
      return al.cbegin();
    }
    typename map<T, vector< edge<T> > >::const_iterator cend(){
      return al.cend();
    }
private:
    std::map<T, vector< edge<T> > > al;
    void insertLabel(T key){
      al[key] = vector<edge<T> >();
    }
};

//mine///////////////////////////////////////////////////////////////////////

template<typename T>
vector<set<T>> makeDisjoint(vector<T> a)
{
	vector<set<T>> ret;
	set<T> all;
	set<T> temp;
	for (int i = 0; i < a.size(); i++)
	{

		if (all.find(a.at(i)) == all.end())
		{
			temp.insert(a.at(i));
			ret.push_back(temp);
			temp.erase(temp.begin());
		}
		all.insert(a.at(i));
	}
	return ret;
}
template<typename T>
void foo(set<edge<T>> something)
{
	for (edge<T> someshit : something)
	{
		std::cout << someshit.va << " to " << someshit.vb << " weight " << someshit.wt << std::endl;
	}
  //std::cout<<std::endl;
}

template<typename T>
bool foundInVector(vector<edge<T>> a, edge<T> b)
{
	for (int i = 0; i < a.size(); i++)
	{
		if (b.va == a.at(i).va && b.vb == a.at(i).vb && b.wt == a.at(i).wt)
			return true;
	}
	return false;
}

template<typename T>
set<T> makeUnion(set<T> a, set<T> b)
{
	set<T> c;
	//a.insert(b.begin(), b.end());
	//std::cout << "making union with ";
	//foo(a);
	//std::cout << " :  and ";
	//foo(b);
	set_union(a.begin(), a.end(), b.begin(), b.end(), inserter(c, c.begin()));
	//std::cout << "\nresult";
	//foo(c);
	return c;
}


template<typename T>
vector<edge<T> > kruskal(graph<T> g)
{
  vector<edge<T> > mst;
  vector<edge<T>> ve;
  set<edge<T>> e;
  int ecounter = 0;
  int k = 0; 
  int v = 0;

  for (auto iter = g.cbegin(); iter != g.cend(); iter++)
  {
	  v++;
	  T vertex = iter->first;
	  vector<edge<T>> edges = g.getEdges(vertex);
	  //std::sort(edges.begin(), edges.end());
	  for (edge<T> E : edges)
	  {
		  std::cout << E.va << " to " << E.vb << " weight " << E.wt << std::endl;
		  if(!foundInVector(ve,E))
		  {
			  ve.push_back(E);
		  }
	  }
  }
  std::sort(ve.begin(), ve.end());

  std::cout << "\n\nset\n";

  for (edge<T> someshit : ve)
  {
	  std::cout << someshit.va << " to " << someshit.vb << " weight " << someshit.wt << std::endl;
  }

  //foo(e);



  vector<edge<T>> vects(ve.begin(), ve.end());
  vector<T> verts;

  for (int i = 0; i < vects.size(); i++) //populates vector of verts with duplicated from edges
  {
	  verts.push_back(vects.at(i).va);
	  verts.push_back(vects.at(i).vb);
  }


  vector<set<T>> unions = makeDisjoint(verts);
 /* for (int i = 0; i < unions.size(); i++)
  {
	  std::cout << "size: " << unions.size() << std::endl;
	  foo(unions.at(i));
	  std::cout << std::endl;
  }*/
  bool mstFound = false;

  for (int i = 0; i < vects.size(); i++) //vects = vector of edges
  {										 //unions is disjoint sets
	  /*for (int j = 0; j < unions.size(); j++)
	  {
		  foo(unions.at(j));
		  std::cout << std::endl;
	  }*/

	  if (unions.size() == 1)
	  {
		  mstFound == true;
		  std::cout << "unions = 1";
		  break;
	  }

	  if (!mstFound)
	  {
		  int first, second;
		  for (int m = 0; m < unions.size(); m++)
		  {
			  if (unions.at(m).find(vects.at(i).va) != unions.at(m).end())
				  first = m;
			  if (unions.at(m).find(vects.at(i).vb) != unions.at(m).end())
				  second = m;
		  }

		  if (first != second)
		  {
			  unions.at(first) = makeUnion(unions.at(first), unions.at(second));
			  /*std::cout << "/ deleting ";
			  foo(unions.at(second));
			  std::cout << std::endl;*/
			  unions.erase(unions.begin() + second);
			  /*for (int j = 0; j < unions.size(); j++)
			  {
				  std::cout << "after deletion ";
				  foo(unions.at(first));
				  std::cout << std::endl;
			  }*/
			  mst.push_back(vects.at(i));
		  }
	  }
  }


  return mst;
}


#endif //KRUSKAL_H
