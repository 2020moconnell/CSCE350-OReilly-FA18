#include <iostream>
#include <string>
#include <vector>
#include <time.h>

#include "kruskal.h"
#include "gtest/gtest.h"

using namespace std;
using std::string;
using std::vector;


template<typename T>
string edges2String(string msg, vector<edge<T> > edges){
  string s = msg;
  for(edge<T> e:edges)
    s+="("+to_string(e.va)+","+to_string(e.vb)+","+to_string(e.wt)+"),";
  return s;
}

template<typename T>
bool onePermOfOther(vector<edge<T> > as,vector<edge<T> >bs ){
    if(as.size()!=bs.size()) return false;
    for(auto ait = as.begin(); ait!=as.end();++ait){
      auto bit = bs.begin();
      while(bit!=bs.end() &&  *bit!=*ait )
        ++bit;
      if (bit == bs.end()) return false;
      bs.erase(bit);
    }
    return true;

}


TEST(ch9_slide4,simple){
    graph<int> g;
    g.addEdge(edge<int>(1,2,2));
    g.addEdge(edge<int>(1,3,4));
    g.addEdge(edge<int>(1,4,7));
    g.addEdge(edge<int>(2,3,6));
    g.addEdge(edge<int>(2,4,3));
    g.addEdge(edge<int>(3,4,1));


    vector<edge<int> > mst = kruskal<int>(g);
    ASSERT_EQ(3,mst.size())<<"For the ch.9 slide 4 example, with 4 nodes, there will be 3 edges in tree";

    vector<edge<int> > gt_mst;
    gt_mst.push_back(edge<int>(1,2,2));
    gt_mst.push_back(edge<int>(2,4,3));
    gt_mst.push_back(edge<int>(3,4,1));

    cout<<edges2String("mst",mst)<<endl;
    cout<<edges2String("gt_mst",gt_mst)<<endl;
    ASSERT_TRUE(onePermOfOther(mst,gt_mst))<<"Your edges are different, tests have unique answers";
}

TEST(ch9_slide13_cf5,simple){
  graph<char> g;
  g.addEdge(edge<char>('a','b',3));
  g.addEdge(edge<char>('a','f',5));
  g.addEdge(edge<char>('a','e',6));
  g.addEdge(edge<char>('b','c',1));
  g.addEdge(edge<char>('b','f',4));
  g.addEdge(edge<char>('c','d',6));
  g.addEdge(edge<char>('c','f',5));//change from slide
  g.addEdge(edge<char>('f','d',5));
  g.addEdge(edge<char>('f','e',2));
  g.addEdge(edge<char>('e','d',8));


  vector<edge<char> > mst = kruskal<char>(g);
  ASSERT_EQ(5,mst.size())<<"For the ch.9 slide 13 example, with 4 nodes, there will be 5 edges in tree";

  vector<edge<char> > gt_mst;
  gt_mst.push_back(edge<char>('a','b',3));
  gt_mst.push_back(edge<char>('b','c',1));
  gt_mst.push_back(edge<char>('b','f',4));
  gt_mst.push_back(edge<char>('f','d',5));
  gt_mst.push_back(edge<char>('f','e',2));

  cout<<edges2String("mst",mst)<<endl;
  cout<<edges2String("gt_mst",gt_mst)<<endl;
  ASSERT_TRUE(onePermOfOther(mst,gt_mst))<<"Your edges are different, tests have unique answers";
}

